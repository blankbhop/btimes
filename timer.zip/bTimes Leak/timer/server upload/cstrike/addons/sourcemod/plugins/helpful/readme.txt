mpbhops.smx

  Fixes issue of func_door bhop blocks being annoying in public servers

simple-chatprocessor.smx

  Useless on CS:GO, only effective for CS:S so that chat colors actually work.

slopeboostfix.smx

  Fixes issue of not getting speed from ramp boosters.

slopefix.smx

  Fixes issue of not getting speed from dropping onto ramps.

teamfullfixer.smx

  Fixes issue of bots and players not spawning from teams being full.

unrealphys.smx

  Makes it so that unreal style works properly.

zr_ammo.smx

  Makes it so that weapons will never run out of ammo.
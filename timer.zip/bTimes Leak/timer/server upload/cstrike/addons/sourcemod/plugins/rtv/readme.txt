customrtv.smx

  RTV plugin, highly configurable through cstrike/cfg/sourcemod/customrtv.cfg
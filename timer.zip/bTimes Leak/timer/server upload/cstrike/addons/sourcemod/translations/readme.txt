scp.cstrike.phrases.txt

  Required for the simple-chatprocessor.smx to work.
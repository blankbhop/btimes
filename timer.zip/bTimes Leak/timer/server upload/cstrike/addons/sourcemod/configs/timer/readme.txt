bots.txt

  bots.txt will configure what the replay bots will do, instructions of how to configure is in the file.

chatranks.txt

  chatranks.txt is configuration for the ranks people can use within !chatranks and !ranks. (will only be effective on CS:S servers)

chatranks_csgo.txt

  chatranks_csgo.txt will only be effective on CS:GO servers.

sounds.txt

  sounds.txt controls what sounds will be played during certain events. For example whenever a player beats a map a clientsided sound will be played, and whenever a record is beat a serverwide sound will be played.

styles.cfg

  styles.cfg is where all the styles within !style works. Instruction on how to configure is within the file.

timeradmin.txt

  timeradmin.txt will control what admin flags control certain aspects of the timer.
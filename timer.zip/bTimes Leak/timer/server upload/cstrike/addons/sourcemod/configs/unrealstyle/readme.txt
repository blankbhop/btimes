gunjump.cfg

  Only purpose of this is to control how using the USP in the unreal style works, you can configure how much boost you gain from shooting a surface.
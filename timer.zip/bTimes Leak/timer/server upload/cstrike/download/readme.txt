This directory contains custom maps, models, and other files downloaded
from gameservers.  Player sprays are in the user_custom subfolder.
It is generally safe to delete this directory at any time.

This directory is usually be mounted into the game's file system as
the "download" write path, and the last search path for "game" files.
See gameinfo.txt for more details.

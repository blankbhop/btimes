base.nav

  Auto-generates .nav files for all maps.
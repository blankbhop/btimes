Majority of these will auto-generate.

  Don't delete unless you want to reset the config to the default.
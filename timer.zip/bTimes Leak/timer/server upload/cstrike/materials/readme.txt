decals

  Materials for paint.smx. Thse materials aren't needed.
    (only delete if paint.smx is removed.)

sprites

  Materials for zones of the timer. Don't remove unless you are using the default zones.
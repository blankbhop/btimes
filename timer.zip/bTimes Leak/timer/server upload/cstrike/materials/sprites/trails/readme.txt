bluelightning

  old btimes(1.8.3) zones.

bluelightningscroll3

  moving zones, used on most CS:GO servers.(works on CS:S)
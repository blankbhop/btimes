bTimes 2.0/server upload

  directory is for everything to upload into your game server, various other readme files   will be in there to describe function of things.

bTimes 2.0/sql import

  directory is for what you need to import into a sql database for the timer to function   properly such as for times to be saved, zones to be saved, player ranks, etc.